# MORE HANGMAN WORDS

words = ("elephant", "giraffe", "tiger", "koala", "dolphin", "penguin", "lemur", "bison", "cougar", "coyote", "buffalo", "zebra", "panther", "boar","monkey","apple", "banana", "orange", "watermelon", "grape", "pineapple", "aardvark","raccoon","skunk")